const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const crypto = require('crypto');
const axios = require('axios');
const { UserModel } = require('../models/user');
const auth = require('../middleware/auth');
const { getOrCreateContentSettings } = require('../models/contentSettings');
const { sendMail } = require('../services/mailer');

const getDisposableEmailDomains = () => {
    try {
        const list = require('disposable-email-domains');
        return Array.isArray(list) ? list : [];
    } catch (_e) {
        return null;
    }
};

const isDisposableEmail = (email) => {
    const domains = getDisposableEmailDomains();
    if (!domains) return false;
    const domain = String(email || '').split('@').pop().toLowerCase().trim();
    if (!domain) return false;
    return domains.includes(domain);
};

async function sendOtpViaMsg91({ phone, otp, purpose }) {
    const authkey = String(process.env.MSG91_AUTH_KEY || '').trim();
    const templateId = String(process.env.MSG91_OTP_TEMPLATE_ID || '').trim();
    const sender = String(process.env.MSG91_SENDER || 'TROZZY').trim();
    const route = String(process.env.MSG91_ROUTE || '4').trim();
    const country = String(process.env.MSG91_COUNTRY || '91').trim();

    if (!authkey || !templateId) {
        throw new Error('MSG91 is not configured (MSG91_AUTH_KEY, MSG91_OTP_TEMPLATE_ID)');
    }

    const payload = {
        authkey,
        sender,
        route,
        country,
        sms: [String(phone)],
        template_id: templateId,
        variables: {
            otp: String(otp),
            purpose: String(purpose || ''),
        },
        response: 'json',
    };

    const res = await axios.post('https://control.msg91.com/api/v5/flow/', payload);
    if (res.data?.type !== 'success') {
        throw new Error(res.data?.message || 'MSG91 OTP send failed');
    }
    return { success: true, messageId: res.data?.messageid };
}

async function verifyMsg91WidgetAccessToken(accessToken) {
    const authkey = String(process.env.MSG91_AUTH_KEY || '').trim();
    if (!authkey) throw new Error('MSG91_AUTH_KEY missing');

    const token = String(accessToken || '').trim();
    if (!token) throw new Error('accessToken is required');

    const res = await axios.post(
        'https://control.msg91.com/api/v5/widget/verifyAccessToken',
        { accessToken: token },
        {
            headers: {
                authkey,
                'Content-Type': 'application/json',
            },
        },
    );

    const data = res.data;
    const ok = data?.type === 'success' || data?.success === true;
    if (!ok) {
        throw new Error(data?.message || 'MSG91 accessToken verification failed');
    }

    return data;
}

function normalizePhone(phone) {
    const raw = String(phone || '');
    const digits = raw.replace(/\D/g, '');
    if (!digits) return '';
    if (digits.length === 10) return digits;
    if (digits.length > 10) return digits.slice(-10);
    return digits;
}

function generateOtp() {
    return String(Math.floor(100000 + Math.random() * 900000));
}

function otpHash(otp) {
    return crypto.createHash('sha256').update(String(otp)).digest('hex');
}

function pickUserForClient(userDoc, settings) {
    const u = userDoc && typeof userDoc.toObject === 'function' ? userDoc.toObject() : userDoc;
    if (!u) return u;

    const avatarUrl = String(u.avatarUrl || '').trim();
    const defaultAvatarUrl = settings ? String(settings.defaultAvatarUrl || '').trim() : '';

    return {
        ...u,
        avatarUrl: avatarUrl || defaultAvatarUrl,
        bio: String(u.bio || ''),
    };
}

// POST /api/auth/login - Login user
router.post('/login', [
    body('identifier')
        .notEmpty()
        .withMessage('Email or phone is required')
        .isString(),
    body('password')
        .notEmpty()
        .withMessage('Password is required')
        .isLength({ min: 6 })
        .withMessage('Password must be at least 6 characters long')
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            success: false,
            message: 'Validation failed',
            errors: errors.array().map(error => error.msg)
        });
    }
    try {
        const identifierRaw = String(req.body?.identifier || '').trim();
        const password = String(req.body?.password || '');
        const identifierLower = identifierRaw.toLowerCase();

        const isEmail = identifierLower.includes('@');
        const phone = isEmail ? '' : normalizePhone(identifierRaw);
        const email = isEmail ? identifierLower : '';

        // Find user and include password
        const user = await UserModel.findOne(isEmail ? { email } : { phone }).select('+password');

        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password'
            });
        }

        // Check if user is active
        if (!user.active) {
            return res.status(401).json({
                success: false,
                message: 'Account is deactivated'
            });
        }

        // Compare password
        const isPasswordValid = await user.comparePassword(password);

        if (!isPasswordValid) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password'
            });
        }

        // Update last login
        user.lastLogin = new Date();
        user.lastActiveAt = new Date();
        await user.save();

        // Generate token
        const token = user.generateToken();

        // Remove password from response
        user.password = undefined;

        const settings = await getOrCreateContentSettings();
        const userPayload = pickUserForClient(user, settings);

        res.json({
            success: true,
            message: 'Login successful',
            data: {
                user: userPayload,
                token
            }
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({
            success: false,
            message: 'Login failed'
        });
    }
});

function otpGone(_req, res) {
    return res.status(410).json({
        success: false,
        message: 'OTP-based authentication has been disabled. Please use password login/register.',
    });
}

router.post('/register/send-otp', otpGone);
router.post('/login/send-otp', otpGone);
router.post('/verify-otp', otpGone);
router.post('/widget/verify-access-token', otpGone);

// POST /api/auth/register/send-otp - Register start via mobile OTP
router.post('/register/send-otp', [
    body('name').notEmpty().withMessage('Name is required').isString().isLength({ min: 2, max: 100 }),
    body('email').notEmpty().withMessage('Please provide a valid email address').isEmail().normalizeEmail(),
    body('phone').notEmpty().withMessage('Phone is required').isString().isLength({ min: 10, max: 20 }),
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            success: false,
            message: 'Validation failed',
            errors: errors.array().map((error) => error.msg),
        });
    }

    try {
        const name = String(req.body?.name || '').trim();
        const email = String(req.body?.email || '').trim().toLowerCase();
        const phone = normalizePhone(req.body?.phone);

        if (!phone || phone.length < 10) {
            return res.status(400).json({ success: false, message: 'Invalid phone number' });
        }

        const existingEmail = await UserModel.findOne({ email });
        if (existingEmail) {
            return res.status(409).json({ success: false, message: 'User with this email already exists' });
        }

        const existingPhone = await UserModel.findOne({ phone });
        if (existingPhone) {
            return res.status(409).json({ success: false, message: 'User with this phone number already exists' });
        }

        const otp = generateOtp();
        const expiresAt = new Date(Date.now() + 5 * 60 * 1000);

        const parts = name.split(/\s+/).filter(Boolean);
        const firstName = parts[0] || name;
        const lastName = parts.length > 1 ? parts.slice(1).join(' ') : 'User';

        const user = new UserModel({
            firstName,
            lastName,
            email,
            phone,
            phoneVerified: false,
            otpHash: otpHash(otp),
            otpExpiresAt: expiresAt,
            otpPurpose: 'register',
            active: true,
            emailVerified: true,
        });

        await user.save();

        try {
            await sendOtpViaMsg91({ phone, otp, purpose: 'register' });
        } catch (e) {
            console.error('MSG91 send-otp (register) error:', e?.message || e);
            if (String(process.env.NODE_ENV || '').toLowerCase() === 'production') {
                return res.status(500).json({ success: false, message: 'Failed to send OTP' });
            }
            console.log(`📲 OTP (register) for ${phone}: ${otp}`);
        }

        return res.json({
            success: true,
            message: 'OTP sent',
            data: {
                phone,
                purpose: 'register',
                expiresAt: expiresAt.toISOString(),
                ...(String(process.env.NODE_ENV || '').toLowerCase() !== 'production' ? { otp } : {}),
            },
        });
    } catch (error) {
        console.error('Register send-otp error:', error);
        return res.status(500).json({ success: false, message: 'Failed to send OTP' });
    }
});

// POST /api/auth/login/send-otp - Login via mobile OTP
router.post('/login/send-otp', [
    body('phone').notEmpty().withMessage('Phone is required').isString().isLength({ min: 10, max: 20 }),
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            success: false,
            message: 'Validation failed',
            errors: errors.array().map((error) => error.msg),
        });
    }

    try {
        const phone = normalizePhone(req.body?.phone);
        if (!phone || phone.length < 10) {
            return res.status(400).json({ success: false, message: 'Invalid phone number' });
        }

        const user = await UserModel.findOne({ phone }).select('+otpHash +otpExpiresAt +otpPurpose');
        if (!user) {
            return res.status(404).json({ success: false, message: 'Account not found for this phone number' });
        }

        if (!user.active) {
            return res.status(401).json({ success: false, message: 'Account is deactivated' });
        }

        const otp = generateOtp();
        const expiresAt = new Date(Date.now() + 5 * 60 * 1000);

        user.otpHash = otpHash(otp);
        user.otpExpiresAt = expiresAt;
        user.otpPurpose = 'login';
        await user.save();

        try {
            await sendOtpViaMsg91({ phone, otp, purpose: 'login' });
        } catch (e) {
            console.error('MSG91 send-otp (login) error:', e?.message || e);
            if (String(process.env.NODE_ENV || '').toLowerCase() === 'production') {
                return res.status(500).json({ success: false, message: 'Failed to send OTP' });
            }
            console.log(`📲 OTP (login) for ${phone}: ${otp}`);
        }

        return res.json({
            success: true,
            message: 'OTP sent',
            data: {
                phone,
                purpose: 'login',
                expiresAt: expiresAt.toISOString(),
                ...(String(process.env.NODE_ENV || '').toLowerCase() !== 'production' ? { otp } : {}),
            },
        });
    } catch (error) {
        console.error('Login send-otp error:', error);
        return res.status(500).json({ success: false, message: 'Failed to send OTP' });
    }
});

// POST /api/auth/verify-otp - Verify OTP for register/login and issue token
router.post('/verify-otp', [
    body('phone').notEmpty().withMessage('Phone is required').isString(),
    body('otp').notEmpty().withMessage('OTP is required').isString().isLength({ min: 4, max: 8 }),
    body('purpose').optional().isIn(['register', 'login']),
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            success: false,
            message: 'Validation failed',
            errors: errors.array().map((error) => error.msg),
        });
    }

    try {
        const phone = normalizePhone(req.body?.phone);
        const otp = String(req.body?.otp || '').trim();
        const purpose = req.body?.purpose ? String(req.body.purpose) : null;

        const user = await UserModel.findOne({ phone }).select('+otpHash +otpExpiresAt +otpPurpose');
        if (!user) {
            return res.status(404).json({ success: false, message: 'Account not found' });
        }

        if (!user.active) {
            return res.status(401).json({ success: false, message: 'Account is deactivated' });
        }

        if (!user.otpHash || !user.otpExpiresAt || !user.otpPurpose) {
            return res.status(400).json({ success: false, message: 'OTP not requested or already used' });
        }

        if (purpose && user.otpPurpose !== purpose) {
            return res.status(400).json({ success: false, message: 'OTP purpose mismatch' });
        }

        if (new Date(user.otpExpiresAt).getTime() < Date.now()) {
            return res.status(400).json({ success: false, message: 'OTP expired' });
        }

        const ok = otpHash(otp) === String(user.otpHash);
        if (!ok) {
            return res.status(400).json({ success: false, message: 'Invalid OTP' });
        }

        user.phoneVerified = true;
        user.otpHash = null;
        user.otpExpiresAt = null;
        user.otpPurpose = undefined;
        user.lastLogin = new Date();
        user.lastActiveAt = new Date();
        await user.save();

        const token = user.generateToken();
        user.password = undefined;

        return res.json({
            success: true,
            message: 'OTP verified',
            data: {
                user,
                token,
            },
        });
    } catch (error) {
        console.error('Verify OTP error:', error);
        return res.status(500).json({ success: false, message: 'Failed to verify OTP' });
    }
});

// POST /api/auth/widget/verify-access-token - Verify MSG91 Widget accessToken and issue token
router.post('/widget/verify-access-token', [
    body('accessToken').notEmpty().withMessage('accessToken is required').isString(),
    body('purpose').optional().isIn(['register', 'login']),
    body('phone').optional().isString(),
    body('email').optional().isString(),
    body('name').optional().isString(),
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            success: false,
            message: 'Validation failed',
            errors: errors.array().map((error) => error.msg),
        });
    }

    try {
        const purpose = req.body?.purpose ? String(req.body.purpose) : 'login';
        const accessToken = String(req.body?.accessToken || '').trim();
        const msg91 = await verifyMsg91WidgetAccessToken(accessToken);

        const verifiedPhoneRaw =
            msg91?.data?.mobile ||
            msg91?.data?.phone ||
            msg91?.mobile ||
            msg91?.phone ||
            msg91?.identifier;

        const verifiedEmailRaw = msg91?.data?.email || msg91?.email;
        const phone = normalizePhone(verifiedPhoneRaw || req.body?.phone);
        const email = String(verifiedEmailRaw || req.body?.email || '').trim().toLowerCase();

        if (purpose === 'login') {
            if (!phone) {
                return res.status(400).json({ success: false, message: 'Verified phone number missing' });
            }

            const user = await UserModel.findOne({ phone });
            if (!user) {
                return res.status(404).json({ success: false, message: 'Account not found for this phone number' });
            }

            if (!user.active) {
                return res.status(401).json({ success: false, message: 'Account is deactivated' });
            }

            user.phoneVerified = true;
            user.lastLogin = new Date();
            user.lastActiveAt = new Date();
            await user.save();

            const token = user.generateToken();
            user.password = undefined;

            return res.json({
                success: true,
                message: 'Login successful',
                data: {
                    user,
                    token,
                },
            });
        }

        if (!phone) {
            return res.status(400).json({ success: false, message: 'Verified phone number missing' });
        }

        const name = String(req.body?.name || '').trim();
        if (!name) {
            return res.status(400).json({ success: false, message: 'Name is required' });
        }
        if (!email) {
            return res.status(400).json({ success: false, message: 'Email is required' });
        }

        const existingEmail = await UserModel.findOne({ email });
        if (existingEmail) {
            return res.status(409).json({ success: false, message: 'User with this email already exists' });
        }

        const existingPhone = await UserModel.findOne({ phone });
        if (existingPhone) {
            return res.status(409).json({ success: false, message: 'User with this phone number already exists' });
        }

        const parts = name.split(/\s+/).filter(Boolean);
        const firstName = parts[0] || name;
        const lastName = parts.length > 1 ? parts.slice(1).join(' ') : 'User';

        const user = new UserModel({
            firstName,
            lastName,
            email,
            phone,
            phoneVerified: true,
            active: true,
            emailVerified: true,
        });

        await user.save();
        const token = user.generateToken();
        user.password = undefined;

        return res.json({
            success: true,
            message: 'Registration successful',
            data: {
                user,
                token,
            },
        });
    } catch (error) {
        console.error('Widget verify-access-token error:', error);
        return res.status(500).json({ success: false, message: 'Failed to verify access token' });
    }
});

// POST /api/auth/register - Register new user
router.post('/register', [
    body('firstName')
        .notEmpty()
        .withMessage('First name is required')
        .isString()
        .isLength({ min: 2, max: 50 })
        .withMessage('First name must be between 2 and 50 characters'),
    body('lastName')
        .notEmpty()
        .withMessage('Last name is required')
        .isString()
        .isLength({ min: 2, max: 50 })
        .withMessage('Last name must be between 2 and 50 characters'),
    body('email')
        .notEmpty()
        .withMessage('Please provide a valid email address')
        .isEmail()
        .normalizeEmail(),
    body('password')
        .notEmpty()
        .withMessage('Password is required')
        .isLength({ min: 6 })
        .withMessage('Password must be at least 6 characters long'),
    body('phone')
        .optional()
        .isString()
        .isLength({ min: 10, max: 15 })
        .withMessage('Phone number must be between 10 and 15 characters'),
    body('role').optional().isString()
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            success: false,
            message: 'Validation failed',
            errors: errors.array().map(error => error.msg)
        });
    }
    try {
        const firstName = String(req.body?.firstName || '').trim();
        const lastName = String(req.body?.lastName || '').trim();
        const email = String(req.body?.email || '').trim().toLowerCase();
        const password = String(req.body?.password || '');
        const phone = req.body?.phone ? normalizePhone(req.body.phone) : '';

        if (isDisposableEmail(email)) {
            return res.status(400).json({
                success: false,
                message: 'Disposable/tempmail email addresses are not allowed',
            });
        }

        // Check if user already exists
        const existingByEmail = await UserModel.findOne({ email });
        if (existingByEmail) {
            return res.status(409).json({ success: false, message: 'User with this email already exists' });
        }

        if (phone) {
            const existingByPhone = await UserModel.findOne({ phone });
            if (existingByPhone) {
                return res.status(409).json({ success: false, message: 'User with this phone number already exists' });
            }
        }

        // Create new user (NEVER accept role from client)
        const user = new UserModel({
            firstName,
            lastName,
            email,
            password,
            phone,
            role: 'user',
            active: true,
            emailVerified: true,
            phoneVerified: Boolean(phone),
        });

        await user.save();

        const token = user.generateToken();
        user.password = undefined;

        const settings = await getOrCreateContentSettings();
        const userPayload = pickUserForClient(user, settings);

        res.status(201).json({
            success: true,
            message: 'Registration successful',
            data: {
                user: userPayload,
                token,
            },
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({
            success: false,
            message: 'Registration failed'
        });
    }
});

// POST /api/auth/forgot-password - Request password reset link
router.post('/forgot-password', [
    body('email')
        .notEmpty()
        .withMessage('Please provide a valid email address')
        .isEmail()
        .normalizeEmail(),
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            success: false,
            message: 'Validation failed',
            errors: errors.array().map(error => error.msg)
        });
    }

    try {
        const email = String(req.body?.email ?? '').trim().toLowerCase();

        let devResetUrl = null;

        // Always return success to avoid leaking whether an email exists
        const user = await UserModel.findOne({ email }).select('+resetPasswordTokenHash +resetPasswordExpires');
        if (user) {
            const rawToken = crypto.randomBytes(32).toString('hex');
            const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');

            user.resetPasswordTokenHash = tokenHash;
            user.resetPasswordExpires = new Date(Date.now() + 60 * 60 * 1000); // 1 hour
            await user.save();

            const envAppBaseUrl = String(process.env.APP_BASE_URL || '').trim();
            const originHeader = String(req.headers?.origin || '').trim();
            const inferredBaseUrl = originHeader || '';
            const appBaseUrl = envAppBaseUrl || inferredBaseUrl;

            const resetUrl = appBaseUrl
                ? `${appBaseUrl.replace(/\/$/, '')}/reset-password?token=${rawToken}`
                : `RESET_TOKEN=${rawToken}`;

            if (String(process.env.NODE_ENV || '').toLowerCase() !== 'production') {
                devResetUrl = appBaseUrl
                    ? `${appBaseUrl.replace(/\/$/, '')}/reset-password?token=${rawToken}`
                    : `/reset-password?token=${rawToken}`;
            }

            console.log('🔐 Password reset requested for:', email);
            console.log('🔗 Reset link/token:', resetUrl);

            if (appBaseUrl) {
                try {
                    await sendMail({
                        to: user.email,
                        subject: 'Reset your password',
                        html: `
                          <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #111;">
                            <h2 style="margin: 0 0 12px 0;">Password reset</h2>
                            <p style="margin: 0 0 12px 0;">We received a request to reset your password.</p>
                            <p style="margin: 0 0 12px 0;">Click this link to reset your password (valid for 1 hour):</p>
                            <p style="margin: 0 0 16px 0;">
                              <a href="${resetUrl}" style="color: #2563eb;">Reset Password</a>
                            </p>
                            <p style="margin: 0; font-size: 12px; color: #555;">If you didn’t request this, you can ignore this email.</p>
                          </div>
                        `,
                    });
                } catch (mailError) {
                    console.error('Forgot password email send error:', mailError);
                }
            } else {
                console.warn('APP_BASE_URL missing and Origin header missing; forgot-password email not sent.');
            }
        }

        return res.json({
            success: true,
            message: 'If an account exists for this email, a password reset link has been generated.',
            ...(devResetUrl ? { data: { resetUrl: devResetUrl } } : {}),
        });
    } catch (error) {
        console.error('Forgot password error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to process forgot password request'
        });
    }
});

// POST /api/auth/reset-password - Reset password using token
router.post('/reset-password', [
    body('token')
        .notEmpty()
        .withMessage('Reset token is required'),
    body('newPassword')
        .notEmpty()
        .withMessage('New password is required')
        .isLength({ min: 6 })
        .withMessage('Password must be at least 6 characters long'),
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            success: false,
            message: 'Validation failed',
            errors: errors.array().map(error => error.msg)
        });
    }

    try {
        const token = String(req.body?.token ?? '').trim();
        const newPassword = String(req.body?.newPassword ?? '');

        const tokenHash = crypto.createHash('sha256').update(token).digest('hex');

        const user = await UserModel.findOne({
            resetPasswordTokenHash: tokenHash,
            resetPasswordExpires: { $gt: new Date() },
        }).select('+password +resetPasswordTokenHash +resetPasswordExpires');

        if (!user) {
            return res.status(400).json({
                success: false,
                message: 'Invalid or expired reset token'
            });
        }

        user.password = newPassword;
        user.resetPasswordTokenHash = null;
        user.resetPasswordExpires = null;
        await user.save();

        return res.json({
            success: true,
            message: 'Password reset successful'
        });
    } catch (error) {
        console.error('Reset password error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to reset password'
        });
    }
});

// GET /api/auth/me - Get current user
router.get('/me', auth, async (req, res) => {
    try {
        const settings = await getOrCreateContentSettings();
        res.json({
            success: true,
            data: pickUserForClient(req.user, settings),
        });
    } catch (error) {
        console.error('Auth me error:', error);
        res.json({
            success: true,
            data: req.user,
        });
    }
});

router.post('/ping', auth, async (req, res) => {
    try {
        await UserModel.findByIdAndUpdate(
            req.user._id,
            { $set: { lastActiveAt: new Date() } },
            { new: false }
        );
        res.json({ success: true });
    } catch (error) {
        console.error('Auth ping error:', error);
        res.status(500).json({ success: false, message: 'Failed to update activity' });
    }
});

// PUT /api/auth/me - Update current user profile/address
router.put('/me', auth, async (req, res) => {
    try {
        const settings = await getOrCreateContentSettings();

        if (!settings.enableProfileEditing) {
            return res.status(403).json({ success: false, message: 'Profile editing is disabled' });
        }

        const allowed = ['firstName', 'lastName', 'phone', 'address', 'bio', 'avatarUrl'];
        const next = {};
        for (const k of allowed) {
            if (req.body?.[k] !== undefined) next[k] = req.body[k];
        }

        if (next.bio !== undefined) {
            const bio = String(next.bio ?? '');
            if (bio.length > Number(settings.bioMaxLength ?? 500)) {
                return res.status(400).json({
                    success: false,
                    message: `Bio cannot exceed ${Number(settings.bioMaxLength ?? 500)} characters`,
                });
            }
            next.bio = bio;
        }

        if (next.avatarUrl !== undefined) {
            next.avatarUrl = String(next.avatarUrl ?? '').trim().slice(0, 2048);
        }

        if (next.address && typeof next.address === 'object') {
            const a = next.address;
            next.address = {
                line1: a.line1 ?? a.addressLine1 ?? a.line_1 ?? '',
                line2: a.line2 ?? a.addressLine2 ?? a.line_2 ?? '',
                city: a.city ?? '',
                state: a.state ?? '',
                postalCode: a.postalCode ?? a.pincode ?? a.zip ?? '',
                country: a.country ?? '',
            };
        }

        const updated = await UserModel.findByIdAndUpdate(
            req.user._id,
            { $set: next },
            { new: true, runValidators: true, projection: { password: 0 } }
        );

        res.json({ success: true, data: pickUserForClient(updated, settings) });
    } catch (error) {
        console.error('Update profile error:', error);
        res.status(500).json({ success: false, message: 'Failed to update profile' });
    }
});

// PUT /api/auth/change-password - Change password
router.put('/change-password', auth, async (req, res) => {
    try {
        const currentPassword = String(req.body?.currentPassword ?? '');
        const newPassword = String(req.body?.newPassword ?? '');

        if (!currentPassword || !newPassword) {
            return res.status(400).json({ success: false, message: 'Current password and new password are required' });
        }

        if (newPassword.length < 6) {
            return res.status(400).json({ success: false, message: 'Password must be at least 6 characters long' });
        }

        const user = await UserModel.findById(req.user._id).select('+password');
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        const ok = await user.comparePassword(currentPassword);
        if (!ok) {
            return res.status(400).json({ success: false, message: 'Current password is incorrect' });
        }

        user.password = newPassword;
        await user.save();

        res.json({ success: true, message: 'Password updated successfully' });
    } catch (error) {
        console.error('Change password error:', error);
        res.status(500).json({ success: false, message: 'Failed to change password' });
    }
});

// POST /api/auth/logout - Logout user (client-side token removal)
router.post('/logout', auth, (req, res) => {
    res.json({
        success: true,
        message: 'Logout successful'
    });
});

module.exports = router;
